import React from 'react';
import { useState, useEffect } from 'react';
import { Paper, Summary, ResearchGap } from './types/research';
import { paperService } from './services/paperService';
import { llmService } from './services/llmService';
import { PaperCard } from './components/PaperCard';
import { SummaryPanel } from './components/SummaryPanel';
import { ResearchGapsPanel } from './components/ResearchGapsPanel';
import { LoadingSpinner } from './components/LoadingSpinner';
import { SearchBar } from './components/SearchBar';
import { Brain, FileText, Target, Sparkles } from 'lucide-react';

function App() {
  const [papers, setPapers] = useState<Paper[]>([]);
  const [selectedPapers, setSelectedPapers] = useState<Paper[]>([]);
  const [summaries, setSummaries] = useState<Summary[]>([]);
  const [researchGaps, setResearchGaps] = useState<ResearchGap[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadPapers();
  }, []);

  const loadPapers = async () => {
    setIsLoading(true);
    try {
      const allPapers = await paperService.getAllPapers();
      setPapers(allPapers);
    } catch (error) {
      console.error('Error loading papers:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    setIsLoading(true);
    try {
      const results = query.trim() 
        ? await paperService.searchPapers(query)
        : await paperService.getAllPapers();
      setPapers(results);
    } catch (error) {
      console.error('Error searching papers:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePaperSelect = (paper: Paper) => {
    setSelectedPapers(prev => {
      const isSelected = prev.some(p => p.id === paper.id);
      if (isSelected) {
        return prev.filter(p => p.id !== paper.id);
      } else {
        return [...prev, paper];
      }
    });
  };

  const analyzeSelectedPapers = async () => {
    if (selectedPapers.length === 0) return;
    
    setIsAnalyzing(true);
    try {
      const results = await llmService.analyzeMultiplePapers(selectedPapers);
      setSummaries(results.map(r => r.summary));
      
      // Combine all gaps and remove duplicates
      const allGaps = results.flatMap(r => r.gaps);
      const uniqueGaps = allGaps.filter((gap, index, self) => 
        index === self.findIndex(g => g.title === gap.title)
      );
      setResearchGaps(uniqueGaps);
    } catch (error) {
      console.error('Error analyzing papers:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const clearAnalysis = () => {
    setSelectedPapers([]);
    setSummaries([]);
    setResearchGaps([]);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Brain className="w-8 h-8 text-blue-600 mr-3" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  Intelligent Research Assistant
                </h1>
                <p className="text-gray-600">
                  AI-powered academic paper analysis and research gap identification
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-sm text-gray-500">
                {selectedPapers.length} paper{selectedPapers.length !== 1 ? 's' : ''} selected
              </div>
              {selectedPapers.length > 0 && (
                <div className="flex space-x-2">
                  <button
                    onClick={analyzeSelectedPapers}
                    disabled={isAnalyzing}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
                  >
                    <Sparkles className="w-4 h-4 mr-2" />
                    {isAnalyzing ? 'Analyzing...' : 'Analyze Papers'}
                  </button>
                  <button
                    onClick={clearAnalysis}
                    className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
                  >
                    Clear Selection
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Papers */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                <FileText className="w-6 h-6 mr-2 text-blue-600" />
                Academic Papers
              </h2>
              <SearchBar 
                onSearch={handleSearch}
                isLoading={isLoading}
              />
            </div>
            
            <div className="space-y-4 max-h-[calc(100vh-300px)] overflow-y-auto">
              {isLoading ? (
                <LoadingSpinner message="Loading papers..." />
              ) : papers.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p>No papers found</p>
                  {searchQuery && (
                    <p className="text-sm">Try adjusting your search terms</p>
                  )}
                </div>
              ) : (
                papers.map(paper => (
                  <PaperCard
                    key={paper.id}
                    paper={paper}
                    onSelect={handlePaperSelect}
                    isSelected={selectedPapers.some(p => p.id === paper.id)}
                  />
                ))
              )}
            </div>
          </div>

          {/* Right Column - Analysis Results */}
          <div className="lg:col-span-2 space-y-8">
            {isAnalyzing ? (
              <div className="bg-white rounded-lg shadow-md">
                <LoadingSpinner 
                  message="Analyzing papers with AI... This may take a few moments."
                  size="lg"
                />
              </div>
            ) : summaries.length === 0 && researchGaps.length === 0 ? (
              <div className="bg-white rounded-lg shadow-md p-12 text-center">
                <Brain className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  Ready to Analyze
                </h3>
                <p className="text-gray-600 mb-4">
                  Select one or more papers from the left panel and click "Analyze Papers" 
                  to generate AI-powered summaries and identify research gaps.
                </p>
                <div className="flex justify-center space-x-8 text-sm text-gray-500">
                  <div className="flex items-center">
                    <FileText className="w-4 h-4 mr-2" />
                    Paper Summaries
                  </div>
                  <div className="flex items-center">
                    <Target className="w-4 h-4 mr-2" />
                    Research Gaps
                  </div>
                </div>
              </div>
            ) : (
              <>
                {/* Summaries */}
                {summaries.map((summary, index) => (
                  <SummaryPanel key={summary.id} summary={summary} />
                ))}
                
                {/* Research Gaps */}
                {researchGaps.length > 0 && (
                  <ResearchGapsPanel gaps={researchGaps} />
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
