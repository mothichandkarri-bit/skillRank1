import React from 'react';
import { Paper } from '../types/research';
import { FileText, Users, Calendar, ExternalLink } from 'lucide-react';

interface PaperCardProps {
  paper: Paper;
  onSelect: (paper: Paper) => void;
  isSelected?: boolean;
}

export const PaperCard: React.FC<PaperCardProps> = ({ paper, onSelect, isSelected }) => {
  return (
    <div 
      className={`bg-white rounded-lg shadow-md p-6 cursor-pointer transition-all duration-200 hover:shadow-lg border-2 ${
        isSelected ? 'border-blue-500 bg-blue-50' : 'border-transparent hover:border-gray-200'
      }`}
      onClick={() => onSelect(paper)}
    >
      <div className="flex items-start justify-between mb-3">
        <h3 className="text-lg font-semibold text-gray-900 line-clamp-2 flex-1">
          {paper.title}
        </h3>
        <FileText className="w-5 h-5 text-gray-400 ml-2 flex-shrink-0" />
      </div>
      
      <div className="flex items-center text-sm text-gray-600 mb-2">
        <Users className="w-4 h-4 mr-1" />
        <span className="truncate">{paper.authors.join(', ')}</span>
      </div>
      
      <div className="flex items-center text-sm text-gray-600 mb-3">
        <Calendar className="w-4 h-4 mr-1" />
        <span>{new Date(paper.publishedDate).toLocaleDateString()}</span>
        {paper.citations && (
          <span className="ml-4 text-blue-600 font-medium">
            {paper.citations} citations
          </span>
        )}
      </div>
      
      <p className="text-gray-700 text-sm mb-4 line-clamp-3">
        {paper.abstract}
      </p>
      
      <div className="flex flex-wrap gap-2 mb-3">
        {paper.keywords.slice(0, 3).map((keyword, index) => (
          <span 
            key={index}
            className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full"
          >
            {keyword}
          </span>
        ))}
        {paper.keywords.length > 3 && (
          <span className="px-2 py-1 bg-gray-100 text-gray-500 text-xs rounded-full">
            +{paper.keywords.length - 3} more
          </span>
        )}
      </div>
      
      {paper.doi && (
        <div className="flex items-center text-xs text-blue-600 hover:text-blue-800">
          <ExternalLink className="w-3 h-3 mr-1" />
          <span>DOI: {paper.doi}</span>
        </div>
      )}
    </div>
  );
};