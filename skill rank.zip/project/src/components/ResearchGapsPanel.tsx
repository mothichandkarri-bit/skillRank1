import React from 'react';
import { ResearchGap } from '../types/research';
import { Target, AlertCircle, TrendingUp, Clock } from 'lucide-react';

interface ResearchGapsPanelProps {
  gaps: ResearchGap[];
}

export const ResearchGapsPanel: React.FC<ResearchGapsPanelProps> = ({ gaps }) => {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high': return <AlertCircle className="w-4 h-4" />;
      case 'medium': return <Clock className="w-4 h-4" />;
      case 'low': return <TrendingUp className="w-4 h-4" />;
      default: return <Target className="w-4 h-4" />;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
        <Target className="w-6 h-6 mr-2 text-red-600" />
        Identified Research Gaps
      </h3>
      
      <div className="space-y-6">
        {gaps.map((gap) => (
          <div key={gap.id} className="border border-gray-200 rounded-lg p-5 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-3">
              <h4 className="text-lg font-medium text-gray-900 flex-1">
                {gap.title}
              </h4>
              <span className={`px-3 py-1 rounded-full text-sm font-medium flex items-center ${getPriorityColor(gap.priority)}`}>
                {getPriorityIcon(gap.priority)}
                <span className="ml-1 capitalize">{gap.priority}</span>
              </span>
            </div>
            
            <p className="text-gray-700 mb-4">
              {gap.description}
            </p>
            
            <div className="bg-blue-50 p-4 rounded-lg mb-4">
              <h5 className="font-medium text-blue-900 mb-2">Suggested Approach:</h5>
              <p className="text-blue-800">{gap.suggestedApproach}</p>
            </div>
            
            <div className="flex items-center justify-between text-sm text-gray-500">
              <span>
                Related to {gap.relatedPapers.length} paper{gap.relatedPapers.length !== 1 ? 's' : ''}
              </span>
              <span>
                Identified {new Date(gap.identifiedAt).toLocaleDateString()}
              </span>
            </div>
          </div>
        ))}
      </div>
      
      {gaps.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          <Target className="w-12 h-12 mx-auto mb-3 text-gray-300" />
          <p>No research gaps identified yet.</p>
          <p className="text-sm">Analyze papers to discover potential research opportunities.</p>
        </div>
      )}
    </div>
  );
};