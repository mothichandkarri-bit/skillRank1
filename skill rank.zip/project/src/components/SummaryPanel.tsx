import React from 'react';
import { Summary } from '../types/research';
import { CheckCircle, AlertTriangle, Lightbulb, Microscope } from 'lucide-react';

interface SummaryPanelProps {
  summary: Summary;
}

export const SummaryPanel: React.FC<SummaryPanelProps> = ({ summary }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
        <Microscope className="w-6 h-6 mr-2 text-blue-600" />
        Research Summary
      </h3>
      
      <div className="space-y-6">
        {/* Key Findings */}
        <div>
          <h4 className="text-lg font-medium text-gray-800 mb-3 flex items-center">
            <CheckCircle className="w-5 h-5 mr-2 text-green-600" />
            Key Findings
          </h4>
          <ul className="space-y-2">
            {summary.keyFindings.map((finding, index) => (
              <li key={index} className="flex items-start">
                <div className="w-2 h-2 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0" />
                <span className="text-gray-700">{finding}</span>
              </li>
            ))}
          </ul>
        </div>
        
        {/* Methodology */}
        <div>
          <h4 className="text-lg font-medium text-gray-800 mb-3 flex items-center">
            <Microscope className="w-5 h-5 mr-2 text-blue-600" />
            Methodology
          </h4>
          <p className="text-gray-700 bg-blue-50 p-4 rounded-lg">
            {summary.methodology}
          </p>
        </div>
        
        {/* Limitations */}
        <div>
          <h4 className="text-lg font-medium text-gray-800 mb-3 flex items-center">
            <AlertTriangle className="w-5 h-5 mr-2 text-orange-600" />
            Limitations
          </h4>
          <ul className="space-y-2">
            {summary.limitations.map((limitation, index) => (
              <li key={index} className="flex items-start">
                <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 mr-3 flex-shrink-0" />
                <span className="text-gray-700">{limitation}</span>
              </li>
            ))}
          </ul>
        </div>
        
        {/* Implications */}
        <div>
          <h4 className="text-lg font-medium text-gray-800 mb-3 flex items-center">
            <Lightbulb className="w-5 h-5 mr-2 text-purple-600" />
            Research Implications
          </h4>
          <ul className="space-y-2">
            {summary.implications.map((implication, index) => (
              <li key={index} className="flex items-start">
                <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 mr-3 flex-shrink-0" />
                <span className="text-gray-700">{implication}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
      
      <div className="mt-6 pt-4 border-t border-gray-200">
        <p className="text-sm text-gray-500">
          Generated on {new Date(summary.generatedAt).toLocaleString()}
        </p>
      </div>
    </div>
  );
};