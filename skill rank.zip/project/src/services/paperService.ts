import { Paper } from '../types/research';

// Sample academic papers for demonstration
const samplePapers: Paper[] = [
  {
    id: 'paper-1',
    title: 'Deep Learning Approaches for Natural Language Processing in Academic Research',
    authors: ['Dr. Sarah Chen', 'Prof. Michael Rodriguez', 'Dr. Emily Watson'],
    abstract: 'This paper presents novel deep learning methodologies for processing and analyzing academic literature. We introduce a transformer-based architecture that achieves state-of-the-art performance in document classification and summarization tasks. Our approach demonstrates significant improvements over existing methods, with applications in automated research assistance and knowledge discovery.',
    content: 'Full paper content would be here in a real implementation...',
    publishedDate: '2024-01-15',
    keywords: ['deep learning', 'natural language processing', 'academic research', 'transformers'],
    doi: '10.1000/182',
    citations: 45
  },
  {
    id: 'paper-2',
    title: 'Machine Learning for Automated Literature Review: A Systematic Approach',
    authors: ['Prof. David Kim', 'Dr. Lisa Thompson', 'Dr. James Wilson'],
    abstract: 'We propose a comprehensive framework for automated literature review using machine learning techniques. Our system can identify relevant papers, extract key information, and generate coherent summaries. The methodology combines multiple ML models to achieve robust performance across different research domains.',
    content: 'Full paper content would be here in a real implementation...',
    publishedDate: '2024-02-20',
    keywords: ['machine learning', 'literature review', 'automation', 'information extraction'],
    doi: '10.1000/183',
    citations: 32
  },
  {
    id: 'paper-3',
    title: 'Identifying Research Gaps Through Semantic Analysis of Scientific Publications',
    authors: ['Dr. Anna Kowalski', 'Prof. Robert Chang', 'Dr. Maria Garcia'],
    abstract: 'This study introduces a semantic analysis framework for identifying research gaps in scientific literature. Using advanced NLP techniques and knowledge graphs, we can automatically detect underexplored areas and suggest potential research directions. Our validation shows high accuracy in gap identification across multiple domains.',
    content: 'Full paper content would be here in a real implementation...',
    publishedDate: '2024-03-10',
    keywords: ['semantic analysis', 'research gaps', 'knowledge graphs', 'scientific publications'],
    doi: '10.1000/184',
    citations: 28
  }
];

class PaperService {
  async getAllPapers(): Promise<Paper[]> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    return samplePapers;
  }

  async getPaperById(id: string): Promise<Paper | null> {
    await new Promise(resolve => setTimeout(resolve, 500));
    return samplePapers.find(paper => paper.id === id) || null;
  }

  async searchPapers(query: string): Promise<Paper[]> {
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const lowercaseQuery = query.toLowerCase();
    return samplePapers.filter(paper => 
      paper.title.toLowerCase().includes(lowercaseQuery) ||
      paper.abstract.toLowerCase().includes(lowercaseQuery) ||
      paper.keywords.some(keyword => keyword.toLowerCase().includes(lowercaseQuery)) ||
      paper.authors.some(author => author.toLowerCase().includes(lowercaseQuery))
    );
  }

  async uploadPaper(paperData: Omit<Paper, 'id'>): Promise<Paper> {
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const newPaper: Paper = {
      ...paperData,
      id: `paper-${Date.now()}`
    };
    
    samplePapers.push(newPaper);
    return newPaper;
  }
}

export const paperService = new PaperService();