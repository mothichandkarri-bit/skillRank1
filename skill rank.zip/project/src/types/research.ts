export interface Paper {
  id: string;
  title: string;
  authors: string[];
  abstract: string;
  content: string;
  publishedDate: string;
  keywords: string[];
  doi?: string;
  citations?: number;
}

export interface Summary {
  id: string;
  paperId: string;
  keyFindings: string[];
  methodology: string;
  limitations: string[];
  implications: string[];
  generatedAt: string;
}

export interface ResearchGap {
  id: string;
  title: string;
  description: string;
  relatedPapers: string[];
  priority: 'high' | 'medium' | 'low';
  suggestedApproach: string;
  identifiedAt: string;
}

export interface AnalysisResult {
  summary: Summary;
  gaps: ResearchGap[];
  relatedTopics: string[];
  confidence: number;
}